create view repe as (select
                       `numsto`.`pid`              AS `pid`,
                       `storage`.`product`.`pname` AS `pname`,
                       `numsto`.`numss`            AS `numss`
                     from (`storage`.`numsto`
                       join `storage`.`product` on ((`numsto`.`pid` = `storage`.`product`.`pid`))));

