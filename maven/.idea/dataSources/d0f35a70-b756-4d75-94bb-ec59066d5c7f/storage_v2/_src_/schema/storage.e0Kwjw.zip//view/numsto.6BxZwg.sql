create view numsto as (select
                         `invi`.`pid`                                                                  AS `pid`,
                         (`invi`.`insumnum` - if(isnull(`outiv`.`outsumnum`), 0, `outiv`.`outsumnum`)) AS `numss`
                       from (`storage`.`invi`
                         join `storage`.`outiv` on ((`invi`.`pid` = `outiv`.`pid`))));

