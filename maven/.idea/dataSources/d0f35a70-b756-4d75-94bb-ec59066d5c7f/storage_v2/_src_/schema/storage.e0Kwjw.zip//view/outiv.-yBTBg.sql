create view outiv as (select
                        `outview`.`pid`         AS `pid`,
                        sum(`outview`.`outnum`) AS `outsumnum`
                      from `storage`.`outview`
                      group by `outview`.`pid`);

