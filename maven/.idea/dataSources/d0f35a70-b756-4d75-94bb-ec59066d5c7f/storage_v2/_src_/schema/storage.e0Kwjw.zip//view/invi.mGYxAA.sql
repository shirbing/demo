create view invi as (select
                       `inview`.`pid`        AS `pid`,
                       sum(`inview`.`innum`) AS `insumnum`
                     from `storage`.`inview`
                     group by `inview`.`pid`);

