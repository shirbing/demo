create view inview as (select
                         `storage`.`insto`.`inid`   AS `inid`,
                         `storage`.`insto`.`pid`    AS `pid`,
                         `storage`.`insto`.`pname`  AS `pname`,
                         `storage`.`insto`.`name`   AS `name`,
                         `storage`.`insto`.`id`     AS `id`,
                         `storage`.`insto`.`intime` AS `intime`,
                         `storage`.`insto`.`innum`  AS `innum`
                       from `storage`.`insto`);

