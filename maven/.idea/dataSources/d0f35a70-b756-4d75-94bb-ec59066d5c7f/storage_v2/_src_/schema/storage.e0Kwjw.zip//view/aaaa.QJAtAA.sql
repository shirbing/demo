create view aaaa as
  select
    `storage`.`insto`.`pname`                                            AS `pname`,
    (`storage`.`insto`.`innum` - ifnull(`storage`.`outsto`.`outnum`, 0)) AS `insto.innum-IFNULL(outsto.outnum,0)`
  from (`storage`.`insto`
    left join `storage`.`outsto` on ((`storage`.`insto`.`pid` = `storage`.`insto`.`pid`)));

