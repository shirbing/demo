create view outview as (select
                          `storage`.`outsto`.`oid`     AS `oid`,
                          `storage`.`outsto`.`pid`     AS `pid`,
                          `storage`.`outsto`.`pname`   AS `pname`,
                          `storage`.`outsto`.`name`    AS `name`,
                          `storage`.`outsto`.`id`      AS `id`,
                          `storage`.`outsto`.`outtime` AS `outtime`,
                          `storage`.`outsto`.`outnum`  AS `outnum`
                        from `storage`.`outsto`);

